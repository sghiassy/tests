# Documentation

## Building

You need Jekyll and appledoc.  See `build.sh`.

## License

See LICENSE.md.
